    var pictureSource;   // guardará a origem da foto
    var destinationType; // configura o tipo de destino

    // Adicionamos um listener que será executado 
    // quando o dispositivo estiver pronto!
    document.addEventListener("deviceready",onDeviceReady,false);
	
    function onDeviceReady() {
        pictureSource=navigator.camera.PictureSourceType;
        destinationType=navigator.camera.DestinationType;
    }

    // Chama-se função de CallBack! É chamada de volta pelo
    // plugin em caso de sucesso ao tirar a foto!
    function onPhotoDataSuccess(imageData) {
		//Jogamos em uma variável o elemento html que tem
		//como id imagem!
      var mypic = document.getElementById('imagem');
		//Falamos que o src deste elemento passará a ser
		//a imagem que foi tirada!
      mypic.src = "data:image/jpeg;base64," + imageData;
    }


    // Um botão chamará essa função!
    function capturarFoto() {		
      // Chamamos aqui o método getPicture que é implementado pelo Plugin!
      // Ao chamar um desses métodos dos Plugins precisamos passar 3 parametros
      // básicos: Função de CallBack - será chamada de volta pelo plugin se tudo ser certo
      //Função de erro: ... se algo der errado e um array com parametros de configuração,
      //Que irão depender de qual plugin esta sendo usado
      navigator.camera.getPicture(onPhotoDataSuccess, onFail, { quality: 50,
        destinationType: destinationType.DATA_URL });
    }

    // Se algo der errado ... 
    //
    function onFail(message) {
      alert('Deu ruim, porque: ' + message);
    }


